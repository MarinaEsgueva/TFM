function u=u3(x,y)
%Soluci�n de la tercera EdP (articulo Wertz)
u=exp(2*x+2*y);