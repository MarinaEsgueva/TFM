function phi=imq(r,epsilon)
phi=1./sqrt(1+(epsilon*r).^2);