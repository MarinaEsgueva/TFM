function Lu=Lu(x,y)
%T�rmino independiente de la primera EDP
Lu=-1.25*pi^2*sin(pi*x).*cos(pi*y/2);