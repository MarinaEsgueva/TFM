function Lu=Lu3(x,y)
%Termino independiente  de la tercera EDP 
Lu=8*exp(2*x+2*y);