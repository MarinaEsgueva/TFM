function u=u(x,y)
%soluci�n a la EDP1
u=sin(pi*x).*cos(pi*y/2);